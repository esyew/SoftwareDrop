//
// Created by Erick Grant on 1/27/23.
//

#ifndef LUCKY_SEVEN_SRC_USERINTERFACE_H_
#define LUCKY_SEVEN_SRC_USERINTERFACE_H_
using namespace std;
class UserInterface
{
 public:
  static bool AskForMore();
};

#endif //LUCKY_SEVEN_SRC_USERINTERFACE_H_
