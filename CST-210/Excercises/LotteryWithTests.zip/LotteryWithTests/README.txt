Please tell me if the unit tests fail, uses Google GTest, which works well in CLion, but untested in VS. 
Erick Grant