package mileStone1;

import java.util.ArrayList;





public class Inventory {
	private ArrayList<Product> inventory;
	public ArrayList<Product> Inventory() {
		
		return inventory;
		
	}
	public void RemoveFromInventory(int itemId) {
		
	}
	
	
	
	
	

	
}
