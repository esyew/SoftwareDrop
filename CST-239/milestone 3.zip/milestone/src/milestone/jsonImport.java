package milestone;
//import com.fasterxml.jackson.*;
// for future use, not required yet, will replace FillStore() eventually

public class jsonImport {
	
	/*
	  String jsonString = "{    
			   \"name\": \"nadal\",    
			   \"age\": \"35\",
			   \"gender\": \"M\" 
			  }";

			  ObjectMapper objectWriter = new ObjectMapper();
			  
			  Customer customer = objectWriter.readValue(jsonString, Customer.class);
			  
			  System.out.println("customer name : "+customer.getName());
			  */
			  
}
